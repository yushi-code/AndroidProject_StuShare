package com.example.stu_share;

import android.provider.BaseColumns;

public class DBConnect {

    private DBConnect(){};

    public static class DBEntity
            implements BaseColumns
    {
        public static final String TABLE_NAME_USER = "user";
        public static final String COLUMN_NAME_EMAIL = "email";
        public static final String COLUMN_NAME_PSWD = "password";
        public static final String COLUMN_NAME_FN = "first_name";
        public static final String COLUMN_NAME_LN = "last_name";
        public static final String COLUMN_NAME_CC = "college_code";
        public static final String COLUMN_NAME_PC = "program_code";
        public static final String COLUMN_NAME_RY = "registered_year";
        public static final String COLUMN_NAME_EXP = "exprire_year";
        public static final String COLUMN_NAME_STATUS = "status";
        public static final String COLUMN_NAME_Q = "question";
        public static final String COLUMN_NAME_A = "answer";
        public static final String COLUMN_NAME_ROLE = "role";
        public static final String SQL_CREATE_TABLE_USER = "CREATE TABLE "+
                TABLE_NAME_USER + " ( "+
                _ID + " INTEGER PRIMARY KEY, " +
                COLUMN_NAME_EMAIL + " TEXT unique, "+
                COLUMN_NAME_PSWD + " TEXT , "+
                COLUMN_NAME_FN + " TEXT , "+
                COLUMN_NAME_LN + " TEXT , "+
                COLUMN_NAME_CC + " TEXT , "+
                COLUMN_NAME_PC + " TEXT , "+
                COLUMN_NAME_RY + " TEXT , "+
                COLUMN_NAME_EXP + " TEXT , "+
                COLUMN_NAME_STATUS + " TEXT , "+
                COLUMN_NAME_Q + " TEXT , "+
                COLUMN_NAME_A + " TEXT , "+
                COLUMN_NAME_ROLE + " TEXT "+
                " );";

        public static final String TABLE_NAME_EVENT = "event";
        public static final String EVENT_COL_NAME_ORGID = "organizer_id";
        public static final String EVENT_COL_NAME_STATUS = "status";
        public static final String EVENT_COL_NAME_ST_DATE = "start_date";
        public static final String EVENT_COL_NAME_ST_TIME = "start_time";
        public static final String EVENT_COL_NAME_END_DATE = "end_date";
        public static final String EVENT_COL_NAME_END_TIME = "end_time";
        public static final String EVENT_COL_NAME_TITLE = "title";
        public static final String EVENT_COL_NAME_DETAIL = "detail";

        public static final String SQL_CREATE_TABLE_EVENT= "CREATE TABLE "+
                TABLE_NAME_EVENT + " ( "+
                _ID + " INTEGER PRIMARY KEY, " +
                EVENT_COL_NAME_ORGID + " TEXT , "+
                EVENT_COL_NAME_STATUS + " TEXT , "+
                EVENT_COL_NAME_ST_DATE + " TEXT , "+
                EVENT_COL_NAME_ST_TIME + " TEXT , "+
                EVENT_COL_NAME_END_DATE + " TEXT , "+
                EVENT_COL_NAME_END_TIME + " TEXT , "+
                EVENT_COL_NAME_TITLE + " TEXT , "+
                EVENT_COL_NAME_DETAIL + " TEXT "+
                " );";

        public static final String TABLE_NAME_EVENTREG = "event_reg";
        public static final String EVTREG_COL_NAME_EVENTID = "event_id";
        public static final String EVTREG_COL_NAME_USERID = "user_id";
        public static final String EVTREG_COL_NAME_STATUS = "status";


        public static final String SQL_CREATE_TABLE_EVTREG= "CREATE TABLE "+
                TABLE_NAME_EVENTREG + " ( "+
                _ID + " INTEGER PRIMARY KEY, " +
                EVTREG_COL_NAME_EVENTID + " TEXT , "+
                EVTREG_COL_NAME_USERID + " TEXT , "+
                EVTREG_COL_NAME_STATUS + " TEXT"+

                " );";
        public static final String SQL_CREATE=SQL_CREATE_TABLE_USER+SQL_CREATE_TABLE_EVENT+SQL_CREATE_TABLE_EVTREG;
        public static final String SQL_DROP = "DROP TABLE IF EXISTS " + TABLE_NAME_USER
                +" ; \nDROP TABLE IF EXISTS " + TABLE_NAME_EVENT
                +" ; \nDROP TABLE IF EXISTS " + TABLE_NAME_EVENTREG+" ; ";
    }
}

