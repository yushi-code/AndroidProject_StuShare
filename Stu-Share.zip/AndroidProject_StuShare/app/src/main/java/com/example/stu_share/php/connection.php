<?php
$host = "gblearn.com";
$user_name = "w0044421_w004442";
$user_password = "Stushare127";
$db_name = "w0044421_stushare";

$con = mysqli_connect($host, $user_name,$user_password, $db_name);

?>