package com.example.stu_share;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class CarMyCarList extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_car_my_cars);
    }
}
